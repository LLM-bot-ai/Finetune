#pip install flash-attn --no-build-isolation
#pip install datasets
#pip install flash-attention
#pip install peft
#python experiments/run_prediction.py train_configs/simcse/MetaLlama3.json